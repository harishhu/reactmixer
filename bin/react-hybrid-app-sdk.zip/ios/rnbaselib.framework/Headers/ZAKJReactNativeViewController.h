//
//  SAReactNativeViewController.h
//  saadtw
//
//  Created by 姚志飞 on 2018/2/27.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZAKJReactNativeViewController : UIViewController
@property (nonatomic,strong)NSString *modulename;

@property (nonatomic,strong)NSDictionary *launchData;

@end
