let lan_cht = {
    login_button_title: '登錄',
    login_number_prompt: '請輸入賬號',
    login_password_prompt: '請輸入密碼'
}

export default lan_cht;
