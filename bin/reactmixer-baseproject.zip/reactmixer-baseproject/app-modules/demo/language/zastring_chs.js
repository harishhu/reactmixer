let lan_chs = {
    login_button_title: '登录-demo',
    login_number_prompt: '请输入账号',
    login_password_prompt: '请输入密码',
    image_button:'App Home',
    flex_button: 'Demo Widgets'
}

export default lan_chs;
