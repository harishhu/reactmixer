import {
  AppModuleManager
} from 'reactmixer-react-native';

AppModuleManager.initAppEnv();

import home from './../app-modules/home';
import demo from './../app-modules/demo';